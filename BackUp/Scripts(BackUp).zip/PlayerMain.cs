﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMain : MonoBehaviour
{

	// === 캐쉬 ==========================================
	PlayerController playerCtrl;
	private int facingDirection = 1;


	// === 코드（Monobehaviour 기본 기능 구현） ================
	void Awake()
	{
		playerCtrl = GetComponent<PlayerController>();
	}

	void Update()
	{
		// 조작 가능한지 확인
		if (!playerCtrl.activeSts)
		{
			return;
		}

		// 패드 처리
		float joyMv = Input.GetAxis("Horizontal");

		//if (playerCtrl.ropeJump)
		//{
		//	playerCtrl.ActionRopeMove(joyMv);
		//}
		//else if (playerCtrl.IsShoot)
		//{
		//	playerCtrl.ActionRopeSwing(joyMv);
		//}
		//else
		//{
			playerCtrl.ActionMove_2(joyMv);
		//}

		// 캐릭터 방향 회전
		if (joyMv == 1 && facingDirection == -1)
		{
			Flip();
		}
		else if (joyMv == -1 && facingDirection == 1)
		{
			Flip();
		}

		// 점프
		if (Input.GetButtonDown("Jump"))
		{
			playerCtrl.ActionJump();
		}

		// 로프 발사
		if(Input.GetButtonDown("Fire1"))
        {
			playerCtrl.ActionFireRope();
        }

		// 로프에서 위아래 이동 처리
		if(playerCtrl.IsShoot)
        {
			//돌에 로프 지속적으로 업데이트
			if (playerCtrl.hit.transform.tag == "Stone")
			{
				playerCtrl.line.SetPosition(0, playerCtrl.hit.transform.position);
				playerCtrl.line.SetPosition(1, playerCtrl.curHook.transform.position);
				playerCtrl.line.GetComponent<ropeRatio>().grabPos = playerCtrl.hit.transform.position;
			}
			joyMv = Input.GetAxis("Vertical");
			playerCtrl.ActionRopeUpDown(joyMv);
		}

		//나무 애니메이션 처리
		if (playerCtrl.IsShoot && Input.GetKey(KeyCode.E))
		{
			playerCtrl.ActionTreeAnimaiton();
		}

		if (playerCtrl.IsShoot && Input.GetKeyUp(KeyCode.E))
		{
			playerCtrl.ActionTreeJump();
		}

		//돌 끄는 애니메이션
		if(playerCtrl.stonePull && Input.GetKey(KeyCode.E))
        {
			playerCtrl.ActionStone();
        }
		else if(playerCtrl.stonePull && Input.GetKeyUp(KeyCode.E) || !playerCtrl.IsShoot)
        {
			playerCtrl.rigid.bodyType = RigidbodyType2D.Dynamic;
			playerCtrl.stonePull = false;
		}

		
	}

	private void Flip()
	{
		facingDirection *= -1;
		transform.Rotate(0.0f, 180.0f, 0.0f);
	}

}