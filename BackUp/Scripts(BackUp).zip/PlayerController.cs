﻿using System;
using System.Collections;
using System.Collections.Generic;
//using System.Diagnostics;
using UnityEngine;

public class PlayerController : BaseCharacterController
{

	// === 외부 파라미터（Inspector 표시） =====================
	public float initHpMax = 20.0f;
	[Range(0.1f, 100.0f)] public float initSpeed = 1.0f;
	public LineRenderer line;
	public float distance = 10f;
	public LayerMask mask;
	public float step = 0.2f;
	public Rigidbody2D rigid;
	public GameObject hook;
	public GameObject curHook;
	public EdgeCollider2D edge;

	// === 외부 파라미터 ======================================
	[System.NonSerialized] public new float hpMax = 10.0f;
	[System.NonSerialized] public int jumpCount = 0;
	[System.NonSerialized] public bool IsShoot = false;
	[System.NonSerialized] public bool ropeJump = false;
	[System.NonSerialized] public bool stonePull = false;

	// === 캐쉬 ==========================================
	DistanceJoint2D joint;

	// === 내부 파라미터 ======================================

	private Animator moveAnimator; // 부모의 애니메이터
	bool breakEnabled = true;
	float groundFriction = 0.0f;
	Vector3 targetPos;
	public RaycastHit2D hit;
	

	// === 코드（Monobehaviour기본 기능 구현） ================
	protected override void Awake()
	{
		base.Awake();

		// 파라미터 초기화
		speed = initSpeed;
		SetHP(initHpMax, initHpMax);

		rigid = GetComponent<Rigidbody2D>();
		moveAnimator = transform.parent.GetComponent<Animator>();
		joint = GetComponent<DistanceJoint2D>();
		edge = line.GetComponent<EdgeCollider2D>();
		Destroy(curHook);
		joint.enabled = false;
		line.enabled = false;
		edge.enabled = false;
	}

	protected override void Update()
    {
		if (IsShoot && hit.transform.tag != "Stone")
		{
			line.SetPosition(0, transform.position);
			line.SetPosition(1, curHook.transform.position);
			edge.enabled = true;
			Vector3[] points = new Vector3[line.positionCount];
			line.GetPositions(points);
			Vector2[] pointsList = new Vector2[line.positionCount];
			for(int i = 0; i < 2; i++)
            {
				pointsList[i] = ((Vector2)points[i]);
            }
			edge.points = pointsList;

			Vector3 targetDir;
			if (hit.transform.tag == "Ring")
			{
				 targetDir = (joint.connectedBody.transform.position - transform.position).normalized;
			}
			else
			{
				targetDir = (hit.point - (Vector2)transform.position).normalized;
			}
			
			transform.up = targetDir;
		}
	}
    

   
	protected override void FixedUpdateCharacter()
	{
		// 착지했는지 검사
		if (falling)
		{
			if ((grounded && !groundedPrev) || (grounded && Time.fixedTime > jumpStartTime + 1.0f))
			{
				animator.SetTrigger("Idle");
				animator.SetBool("Fall", false);
				switch (jumpCount)
                {
					case 1:
						animator.SetBool("Jump1", false);
						break;
					case 2:
						animator.SetBool("Jump2", false);
						break;
				}
				
				falling = false;
				jumped = false;
				ropeJump = false;
				jumpCount = 0;
			}
		}
		

		// 추락 검사
		if (GetComponent<Rigidbody2D>().velocity.y < 0 && !IsShoot && !isOnSlope)
		{
			if (!grounded && !falling)
			{
				if(!jumped)
                {
					jumpCount = 1;
					jumped = true;
					grounded = false;
					ActionFall();
					//UnityEngine.Debug.Log("jumped = true");
				}
                else
                {
					switch (jumpCount)
					{
						case 1:
							if (!grounded)
							{
								ActionFall();
							}
							break;

						case 2:
							if (!grounded)
							{
								ActionFall();
							}
							break;
					}
				}
			}	
		}

		// 캐릭터 방향
		//transform.localScale = new Vector3(basScaleX * dir, transform.localScale.y, transform.localScale.z);

		// 점프 도중에 가로 이동 감속
		if (jumped && !grounded)
		{
			if (breakEnabled)
			{
				breakEnabled = false;
				speedVx *= 0.9f;
			}
		}

		// 이동 정지(감속) 처리
		if (breakEnabled)
		{
			speedVx *= groundFriction;
		}

		// 카메라
		Camera.main.transform.position = transform.position - Vector3.forward;
	}

	// === 코드（기본 액션） =============================
	public override void ActionMove(float n)
	{
		if (!activeSts)
		{
			return;
		}
		

		// 초기화
		//float dirOld = dir;
		breakEnabled = false;

		// 애니메이션 지정
		float moveSpeed = Mathf.Clamp(n, -1.0f, +1.0f);
		//Debug.Log("moveSpeed : " + moveSpeed);
		if (!jumped && !falling && grounded)
		{
			//UnityEngine.Debug.Log("너도 실행되냐");
			animator.SetFloat("MoveSpeed", moveSpeed);
		}
		animator.speed = 1.0f + moveSpeed;

		// 이동 체크
		if (n != 0.0f)
		{
			// 이동
			//dir = Mathf.Sign(n);
			
			moveSpeed = (moveSpeed < 0.5f) ? (moveSpeed * (1.0f / 0.5f)) : 1.0f;
			Debug.Log("moveSpeed : " + moveSpeed);
			speedVx = initSpeed * moveSpeed;// * dir;
			//Debug.Log("speedVx : " + speedVx);
		}
		else
		{
			// 이동 정지
			breakEnabled = true;
		}

		// 그 시점에서 돌아보기 검사
		//if (dirOld != dir)
		//{
		//	breakEnabled = true;
		//}
	}

	public void ActionMove_2(float n)
    {

    }

	public void ActionRopeSwing(float n)
    {
		dir = Mathf.Sign(n);
		float dirOld = dir;
		breakEnabled = false;

		rigid.AddForce(Vector2.right * n, ForceMode2D.Impulse);

		float maxSpeed = 15f;

		if (rigid.velocity.x > maxSpeed)
			rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
		else if (rigid.velocity.x < maxSpeed * (-1))
			rigid.velocity = new Vector2(maxSpeed * (-1), rigid.velocity.y);

		speedVx = rigid.velocity.x;
		if (hit.transform.CompareTag("Stone") && grounded)
		{
			if ((transform.position.x - hit.transform.position.x > 0 && dir == -1) || (transform.position.x - hit.transform.position.x < 0 && dir == 1))
			{
				speedVx = 0;
			}
			else if (speedVx >= 3) { speedVx = 3; }
			else if (speedVx <= -3) { speedVx = -3; }

			stonePull = true;
		}
		if (rigid.velocity.x >= 0)
		{
			transform.localScale = new Vector3(basScaleX * dir, transform.localScale.y, transform.localScale.z);
		}
		else if (rigid.velocity.x < 0)
		{
			transform.localScale = new Vector3(basScaleX * dir, transform.localScale.y, transform.localScale.z);
		}
	}

	public void ActionRopeMove(float n)
	{
		// 초기화
		float dirOld = dir;
		breakEnabled = false;

		rigid.AddForce(Vector2.right * n, ForceMode2D.Impulse);

		float maxSpeed = 25f;

		if (rigid.velocity.x > maxSpeed)
			rigid.velocity = new Vector2(maxSpeed, rigid.velocity.y);
		else if (rigid.velocity.x < maxSpeed * (-1))
			rigid.velocity = new Vector2(maxSpeed * (-1), rigid.velocity.y);

		speedVx = rigid.velocity.x;

		if (rigid.velocity.x >= 0)
		{
			transform.localScale = new Vector3(basScaleX * dir, transform.localScale.y, transform.localScale.z);
		}
		else if (rigid.velocity.x < 0)
		{
			transform.localScale = new Vector3(basScaleX * dir, transform.localScale.y, transform.localScale.z);
		}
	
	}

	public void ActionJump()
	{
		switch (jumpCount)
		{
			case 0:
				if (grounded)
				{
					animator.SetBool("Jump1", true);
					GetComponent<Rigidbody2D>().velocity = Vector2.up * 20.0f;
					jumpStartTime = Time.fixedTime;
					jumped = true;
					falling = false;
					
					jumpCount++;
				}
				break;
			case 1:
				if (!grounded)
				{
					if (jumpCount == 1)
						animator.SetBool("Jump1", false);
					
					if(animator.GetBool("Rope"))
                    { // 로프에 매달려 있을 시
						animator.SetBool("Rope", false);
						Destroy(curHook);
						joint.enabled = false;
						line.enabled = false;
						IsShoot = false;
						ropeJump = true;
						transform.up = new Vector3(0, 1, 0);
					}
					if (animator.GetBool("Fall"))
					{
						animator.SetBool("Fall", false);
					}
					animator.SetBool("Jump2", true);
					//UnityEngine.Debug.Log("jump2 = true");
					GetComponent<Rigidbody2D>().velocity = Vector2.up * 20.0f;
					//GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, 10.0f);
					jumped = true;
					falling = false;
					

					jumpCount++;
				}
				break;
		}
	}

	public void ActionFall()
    {
		if(!falling)
        {
			animator.SetBool("Fall", true);
			animator.SetFloat("MoveSpeed", 0);
			falling = true;
		}
    }

	public void ActionFireRope()
    {
		if (!IsShoot)
		{
			targetPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			targetPos.z = 0;
			hit = Physics2D.Raycast(transform.position, targetPos - transform.position, distance, mask);

			if (hit.collider != null && hit.collider.gameObject.GetComponent<Rigidbody2D>() != null)
			{ // 레이캐스티을 해서 무언가에 닿았을 때 로프를 생성
				curHook = Instantiate(hook, transform.position, Quaternion.identity);
				curHook.SetActive(true);
				curHook.GetComponent<RopeScript>().destiny = hit.point;

				joint.enabled = true;
				joint.connectedBody = hit.collider.gameObject.GetComponent<Rigidbody2D>();
				if (hit.transform.tag == "Ring" || hit.transform.tag == "Tree" || hit.transform.tag == "Stone")
				{
					joint.connectedAnchor = new Vector2(0, 0);
				}
				else
				{
					joint.connectedAnchor = hit.point - new Vector2(hit.collider.transform.position.x, hit.collider.transform.position.y);
				}
				joint.distance = Vector2.Distance(transform.position, hit.point);

				line.enabled = true;
				line.SetPosition(0, transform.position);
				line.SetPosition(1, curHook.transform.position);


				if (hit.transform.tag == "Stone")
                {
					stonePull = true;
                }

				switch (jumpCount)
				{
					case 1:
						animator.SetBool("Jump1", false);
						break;


					case 2:
						animator.SetBool("Jump2", false);
						break;
				}
				if (animator.GetBool("Fall"))
				{
					animator.SetBool("Fall", false);
				}
				// 
				jumped = true;
				jumpCount = 1;


				animator.SetBool("Rope", true);
				IsShoot = true;
			}
		}
		else
		{
			Destroy(curHook);
			joint.enabled = false;
			line.enabled = false;
			animator.SetBool("Rope", false);
			IsShoot = false;
			transform.up = new Vector3(0, 1, 0);
		}
	}

	public void ActionRopeUpDown(float n)
    {
		if (n > 0)
		{
			if (joint.distance > 1f)
			{
				joint.distance -= step;

			}
			else
			{
				Destroy(curHook);
				joint.enabled = false;
				line.enabled = false;
				IsShoot = false;
				//UnityEngine.Debug.Log("나오냐");
				animator.SetBool("Rope", false);
				animator.SetBool("Fall", true);
				transform.up = new Vector3(0, 1, 0);
			}

		}
		else if (n < 0)
		{

			if (joint.distance > 1f)
			{
				joint.distance += step;

			}
			else
			{
				Destroy(curHook);
				joint.enabled = false;
				line.enabled = false;
			}

		}
	}


	public void ActionTreeAnimaiton()
	{
		if (hit.collider.tag == "Tree")
		{
			line.SetPosition(0, transform.position);
			//line.SetPosition(1, hit.collider.transform.position);
			line.SetPosition(1, curHook.transform.position);
			moveAnimator.SetBool("Tree", true);
			Destroy(curHook);
			joint.enabled = false;
			rigid.bodyType = RigidbodyType2D.Static;
		}
	}
	public void ActionTreeJump()
	{
		if (hit.collider.tag == "Tree")
		{
			Destroy(curHook);
			ropeJump = true;
			rigid.bodyType = RigidbodyType2D.Dynamic;
			moveAnimator.SetBool("Tree", false);
			line.enabled = false;
			rigid.AddForce(new Vector3(1, 1, 0) * 1000f);
		}
	}

	public void ActionStone()
	{
		if (grounded)
		{
			rigid.bodyType = RigidbodyType2D.Static;
			joint.distance -= step / 4;
		}
	}

	
}